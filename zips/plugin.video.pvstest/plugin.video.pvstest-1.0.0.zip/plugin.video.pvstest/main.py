import sys
import xbmcgui
import xbmcplugin

handle = int(sys.argv[1])
xbmcplugin.addDirectoryItem(handle, '', xbmcgui.ListItem('Funguje!'), False)
xbmcplugin.endOfDirectory(handle)
